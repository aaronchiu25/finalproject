-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2020 at 07:16 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `refilling station`
--

-- --------------------------------------------------------

--
-- Table structure for table `chiunima`
--

CREATE TABLE `chiunima` (
  `ID` int(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `NUMBER` varchar(11) NOT NULL,
  `REFILL_ONLY` int(10) NOT NULL,
  `GALLON_WITH_WATER` int(10) NOT NULL,
  `GALLON_WITHOUT_WATER` int(10) NOT NULL,
  `PRICE` int(10) NOT NULL,
  `STATUS` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chiunima`
--

INSERT INTO `chiunima` (`ID`, `NAME`, `ADDRESS`, `NUMBER`, `REFILL_ONLY`, `GALLON_WITH_WATER`, `GALLON_WITHOUT_WATER`, `PRICE`, `STATUS`) VALUES
(1, 'Joseph Aaron Ignacio', '', '09959843116', 5, 5, 0, 125, ''),
(2, 'EYEYRON', 'MALABON', '123', 2, 2, 0, 100, ''),
(3, 'BAMBOO', 'MALABON', '214', 4, 2, 0, 450, 'DELIVERED'),
(4, 'RICO BLANCO', 'MALABON', '214', 20, 10, 0, 2250, 'CANCELED'),
(5, 'SUD', 'WALANG SAGOT SA TANONG', '421321', 213, 213, 0, 42600, 'PENDING'),
(6, 'AGSUNTA', 'STUDIO', '13213', 3, 1, 2, 635, 'CANCELED'),
(7, 'EDGAR', 'PAROKYA NI EDGAR', '3213123', 3, 2, 3, 1015, 'PENDING'),
(8, 'MangJose', 'tuwing sasapit ang dilim', '23123123', 3, 2, 0, 475, 'PENDING'),
(9, 'PAGILAGAN INOM', 'LAKLAK STREET', '09404321224', 5, 5, 0, 1125, 'CANCELED'),
(10, 'Mr. John Smith', '111 samson road', '123456', 1, 1, 1, 405, 'DELIVERED');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chiunima`
--
ALTER TABLE `chiunima`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chiunima`
--
ALTER TABLE `chiunima`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
